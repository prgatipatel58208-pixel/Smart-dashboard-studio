const STORAGE_KEY="smartDashboardStudioV1";
const dashboard=document.getElementById("dashboard");
const emptyState=document.getElementById("emptyState");
const widgetCount=document.getElementById("widgetCount");
const editor=document.getElementById("editor");
const editorFields=document.getElementById("editorFields");
const editorTitle=document.getElementById("editorTitle");
const editorKicker=document.getElementById("editorKicker");
const toast=document.getElementById("toast");
let editingId=null;

const defs={
  goals:{icon:"🎯",title:"Goals",sub:"Progress toward your goals",defaults:{name:"Complete UI/UX Course",progress:65}},
  habits:{icon:"🔥",title:"Habits",sub:"Keep your streak alive",defaults:{streak:12,done:"6 / 8"}},
  tasks:{icon:"📝",title:"Tasks",sub:"Today's checklist",defaults:{items:"Finish chapter\nPractice typing\nReview notes"}},
  study:{icon:"📚",title:"Study",sub:"Today's learning plan",defaults:{subject:"Economics",time:"40 min",progress:58}},
  calendar:{icon:"📅",title:"Calendar",sub:"This month",defaults:{}},
  clock:{icon:"🕐",title:"Clock",sub:"Local time",defaults:{}}
};

let state=loadState();

function uid(){return Date.now().toString(36)+Math.random().toString(36).slice(2,7)}
function loadState(){
  try{
    const saved=JSON.parse(localStorage.getItem(STORAGE_KEY));
    if(saved&&Array.isArray(saved.widgets))return saved;
  }catch(e){}
  return {theme:"dark",widgets:[]};
}
function saveState(show=true){
  localStorage.setItem(STORAGE_KEY,JSON.stringify(state));
  if(show) showToast("Dashboard saved ✓");
}
function showToast(text){
  toast.textContent=text;toast.classList.add("show");
  clearTimeout(showToast.t);showToast.t=setTimeout(()=>toast.classList.remove("show"),1800);
}
function escapeHtml(s){
  return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));
}
function addWidget(type){
  const d=defs[type];
  state.widgets.push({id:uid(),type,data:JSON.parse(JSON.stringify(d.defaults))});
  saveState(false);render();showToast(d.title+" added");
}
function removeWidget(id){
  state.widgets=state.widgets.filter(w=>w.id!==id);saveState(false);render();showToast("Widget removed");
}
function openEditor(id){
  const w=state.widgets.find(x=>x.id===id);if(!w)return;
  editingId=id;editorTitle.textContent="Edit "+defs[w.type].title;editorKicker.textContent=defs[w.type].title.toUpperCase();
  const d=w.data;
  let fields="";
  if(w.type==="goals")fields=field("name","Goal name",d.name)+field("progress","Progress %",d.progress,"number");
  if(w.type==="habits")fields=field("streak","Streak (days)",d.streak,"number")+field("done","Today's habits",d.done);
  if(w.type==="tasks")fields=field("items","Tasks (one per line)",d.items,"textarea");
  if(w.type==="study")fields=field("subject","Subject",d.subject)+field("time","Study time",d.time)+field("progress","Progress %",d.progress,"number");
  if(w.type==="calendar")fields='<div class="muted">Calendar uses your device date automatically. More calendar controls will be added in a later version.</div>';
  if(w.type==="clock")fields='<div class="muted">Clock uses your device time automatically.</div>';
  editorFields.innerHTML=fields;
  editor.showModal();
}
function field(key,label,value,type="text"){
  const tag=type==="textarea"?"textarea":"input";
  const extra=type==="number"?`type="number" min="0" max="100"`:"";
  return `<div class="field"><label>${escapeHtml(label)}</label><${tag} id="f_${key}" ${extra}>${escapeHtml(value??"")}</${tag}></div>`;
}
function saveEditor(){
  const w=state.widgets.find(x=>x.id===editingId);if(!w)return;
  const keys=Object.keys(w.data);
  keys.forEach(k=>{const el=document.getElementById("f_"+k);if(el)w.data[k]=el.value});
  if(w.type==="goals"||w.type==="study")w.data.progress=Math.max(0,Math.min(100,Number(w.data.progress)||0));
  saveState(false);editor.close();render();showToast("Widget updated ✓");
}
function widgetHTML(w){
  const d=w.data,def=defs[w.type];
  let body="";
  if(w.type==="goals")body=`<div class="big-number">${d.progress}%</div><div class="muted">${escapeHtml(d.name)}</div><div class="progress"><i style="width:${d.progress}%"></i></div>`;
  if(w.type==="habits")body=`<div class="big-number">${escapeHtml(d.streak)}</div><div class="muted">day streak</div><div class="pill">Today ${escapeHtml(d.done)}</div>`;
  if(w.type==="tasks"){
    const items=String(d.items||"").split("\n").filter(Boolean);
    body=`<ul class="list">${items.map((x,i)=>`<li class="task"><input type="checkbox" data-task="${w.id}-${i}"><span>${escapeHtml(x)}</span></li>`).join("")}</ul>`;
  }
  if(w.type==="study")body=`<div class="big-number">${escapeHtml(d.progress)}%</div><div class="muted">${escapeHtml(d.subject)} • ${escapeHtml(d.time)}</div><div class="progress"><i style="width:${d.progress}%"></i></div>`;
  if(w.type==="calendar")body=calendarHTML();
  if(w.type==="clock")body=`<div class="clock" data-clock>--:--:--</div><div class="date" data-date>Loading...</div>`;
  const wide=(w.type==="tasks"||w.type==="calendar")?" wide":"";
  return `<article class="widget${wide}" data-id="${w.id}"><div class="widget-head"><div><div class="widget-title">${def.icon} ${def.title}</div><div class="widget-sub">${def.sub}</div></div><div class="widget-tools"><button class="tool edit" data-edit="${w.id}" title="Edit">✎</button><button class="tool remove" data-remove="${w.id}" title="Remove">×</button></div></div><div class="widget-body">${body}</div></article>`;
}
function calendarHTML(){
  const now=new Date(),year=now.getFullYear(),month=now.getMonth();
  const first=new Date(year,month,1).getDay(),days=new Date(year,month+1,0).getDate();
  const names=["S","M","T","W","T","F","S"];
  let out=names.map(x=>`<div class="day"><b>${x}</b></div>`).join("");
  for(let i=0;i<first;i++)out+="<div></div>";
  for(let d=1;d<=days;d++)out+=`<div class="day ${d===now.getDate()?"today":""}">${d}</div>`;
  return `<div class="calendar">${out}</div>`;
}
function updateClocks(){
  const now=new Date(),time=now.toLocaleTimeString(),date=now.toLocaleDateString(undefined,{weekday:"long",day:"2-digit",month:"long",year:"numeric"});
  document.querySelectorAll("[data-clock]").forEach(x=>x.textContent=time);
  document.querySelectorAll("[data-date]").forEach(x=>x.textContent=date);
}
function render(){
  dashboard.innerHTML=state.widgets.map(widgetHTML).join("");
  emptyState.style.display=state.widgets.length?"none":"flex";
  widgetCount.textContent=`${state.widgets.length} widget${state.widgets.length===1?"":"s"}`;
  document.querySelectorAll("[data-edit]").forEach(b=>b.onclick=()=>openEditor(b.dataset.edit));
  document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>removeWidget(b.dataset.remove));
  updateClocks();
}
document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>addWidget(b.dataset.add));
document.getElementById("saveBtn").onclick=()=>saveState(true);
document.getElementById("editorSave").onclick=e=>{e.preventDefault();saveEditor()};
document.getElementById("themeBtn").onclick=()=>{
  state.theme=state.theme==="light"?"dark":"light";
  document.body.classList.toggle("light",state.theme==="light");saveState(false);
};
document.getElementById("resetBtn").onclick=()=>{
  if(confirm("Reset this dashboard to an empty layout?")){state={theme:"dark",widgets:[]};saveState(false);render();showToast("Dashboard reset")}
};
document.body.classList.toggle("light",state.theme==="light");
render();
setInterval(updateClocks,1000);
